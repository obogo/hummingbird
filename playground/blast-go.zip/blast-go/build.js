hb.platform.__package__
hb.platform.errors.__package__
hb.platform.errors.debug
//app.errors.prod
hb.platform.directives.__package__
hb.platform.directives.app
hb.platform.directives.class
hb.platform.directives.cloak
hb.platform.directives.disabled // disabled
hb.platform.directives.events
hb.platform.directives.html     // no
hb.platform.directives.model
hb.platform.directives.repeat
hb.platform.directives.show
hb.platform.directives.src      // no
hb.platform.directives.view
hb.platform.filters.__package__
hb.platform.filters.timeAgo
hb.platform.injector
hb.platform.interpolator
hb.platform.compiler
hb.platform.scope
hb.platform.module
hb.debug.__package__
hb.debug.scopeDebugger
hb.utils.formatters.toTimeAgo
hb.utils.__package__
hb.utils.throttle
hb.utils.trimStrings
helpers.each
browser.ready
formatter.stripHTMLComments
parsers.resolve;
parsers.htmlify
parsers.htmlToDOM
query.core
query.event.bind
query.event.unbind
query.event.unbindAll
query.modify.css
query.modify.class
ajax.cors

//parsers.interpolate